if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config()
}

const express = require('express')
const app = express()
const bcrypt = require('bcrypt')
const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const methodOverride = require('method-override')
const db = require('./db')
const fs = require('fs')

const initializePassport = require('./passport-config')
initializePassport(
  passport,
  async username => {
    const [rows] = await db.query(`
      SELECT *
      FROM accounts
      WHERE usernames = '${username}'
      `)
    return rows[0];
  },
  async id => {
  const [rows] = await db.query(`
    SELECT *
    FROM accounts
    WHERE id = '${id}'
    `)

  return rows[0];
}
)

app.set('view-engine', 'ejs')
app.use(express.urlencoded({ extended: false }))
app.use(flash())
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))

async function currentUsername(userID) {
  const [rows] = await db.query(`
    SELECT usernames
    FROM accounts
    WHERE id = '${userID}'
    `)
    console.log(rows[0])
    return rows[0]
}

app.get('/', checkAuthenticated, async (req, res) => {
  const idk = await currentUsername(req.session.passport.user)
  console.log(idk.usernames)
  res.render('home.ejs', {name : idk.usernames})
})

app.get('/login', checkNotAuthenticated, (req, res) => {
  res.render('login.ejs')
})

app.post('/login', checkNotAuthenticated, passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/login',
  failureFlash: true
}))

app.get('/register', checkNotAuthenticated, (req, res) => {
  res.render('register.ejs')
})

app.post('/register', checkNotAuthenticated, async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10)
    await db.query(`
      INSERT INTO accounts (usernames, passwords)
      VALUES ('${req.body.username}', '${hashedPassword}')
      `)
    res.redirect('/login')
  } catch {
    res.redirect('/register')
  }
})

app.delete('/logout', (req, res) => {
  req.logout(function(err) { 
    if (err) { return next(err); } 
    res.redirect('/login');
  });   
});

function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next()
  }

  res.redirect('/login')
}

function checkNotAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect('/')
  }
  next()
}

app.listen(3000)