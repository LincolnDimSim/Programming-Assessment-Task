delete from lobbies
where id = 2