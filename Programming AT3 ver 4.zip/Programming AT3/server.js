if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config()
}

const express = require('express')
const app = express()
const bcrypt = require('bcrypt')
const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const methodOverride = require('method-override')
const db = require('./db')
const fsp = require('fs/promises')
const fs = require('fs')
const Math = require('math')
const readline = require('readline');
const multer = require('multer')

const initializePassport = require('./passport-config')
initializePassport(
  passport,
  async username => {
    const [rows] = await db.query(`
      SELECT *
      FROM accounts
      WHERE usernames = '${username}'
      `)
    return rows[0];
  },
  async id => {
  const [rows] = await db.query(`
    SELECT *
    FROM accounts
    WHERE id = '${id}'
    `)

  return rows[0];
})

let cacheUsername = null
let cacheLobby = null

app.set('view-engine', 'ejs')
app.use(express.urlencoded({ extended: true }))
app.use(flash())
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))
app.use("/uploads", express.static('uploads'));
app.use(express.text());

const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage });

//Function stuff
async function currentUsername(userID) {
  const [rows] = await db.query(`
    SELECT usernames
    FROM accounts
    WHERE id = '${userID}'
    `)
    return rows[0]
}

async function lobbyIDrender(id) {
  const [rows] = await db.query(`
    SELECT lobby FROM lobbies
    WHERE id = ${id}
  `)
  return rows
}

async function lobbyNAMErender(id) {
  const [rows] = await db.query(`
    SELECT lNames FROM lobbies
    WHERE id = ${id}
  `)
  return rows
}

async function makeLobbyID() {
  var result           = '';
  var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  while (true) {
    for ( var i = 0; i < 6; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * 36));
    }
    [randomChecker] = await db.query('SELECT lobby FROM lobbies WHERE lobby = "' + result + '"')
    if (randomChecker = []) {
      break
    }
  }
  return result;
}

async function waitaminuteok(id, name, idname) {
  await omfgTsAintSyncing(id, name, idname)
}

async function omfgTsAintSyncing(id, name, idname) {
  await db.query(`
        INSERT INTO lobbies (id, lobby, lNames)
        VALUES (${id}, '${name}', '${idname}')
      `)
}
//End
app.get('/', checkAuthenticated, async (req, res) => {
  cacheUsername = await currentUsername(req.session.passport.user)
  const lobbiesN = await lobbyNAMErender(req.session.passport.user)
  const lobbiesID = await lobbyIDrender(req.session.passport.user)
  res.render('home.ejs', {name : cacheUsername.usernames, lobbbyNames: lobbiesN, lobbyID: lobbiesID})
})

app.post('/', checkAuthenticated, async (req, res) => {
  if (fs.existsSync("./lobbies/" + req.body.lFind)) {
    fs.readFile(`./lobbies/${req.body.lFind}/log.txt`, 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        res.redirect('/')
        return;
      }
      const lName = data.split('\n')
      waitaminuteok(req.session.passport.user, req.body.lFind, lName[0])
    })
  }
  res.redirect('/')
})

app.get('/login', checkNotAuthenticated, (req, res) => {
  res.render('login.ejs')

})

app.post('/login', checkNotAuthenticated, passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/login',
  failureFlash: true
}))

app.get('/lobbies/:lobby', checkAuthenticated, async (req, res) => {
  authLobby = await lobbyIDrender(req.session.passport.user)
  const exists = authLobby.some(
    item => item.lobby === req.params.lobby
  );
  if (!exists) {
    res.redirect('/')
  } else {
    cacheLobby = req.params.lobby
    fs.readFile(`./lobbies/${cacheLobby}/log.txt`, 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      req.redirect('/')
      return;
    }
    const data2 = data.split("\r\n")
    Fcontent = []
    data4 = ''
    data5 = []
    Fcontent.push(data2[0])
    for (i = 1; i < data2.length; i++) {
      data5 = []
      data3 = data2[i].split("一")
      if (data3[1] !== '') {
        data4 = (data3[1].slice(0, -1)).split("二")
        for (j = 0; j < data4.length; j++) {
          data5.push(data4[j].split("三"))
        }
      }
      Fcontent.push([data3[0], data5, data3[2]])
    }
    res.render('chat.ejs', {lobby: Fcontent[0], text: Fcontent, code: cacheLobby})
  });
  }
})

app.post('/lobbies/:lobby', checkAuthenticated, upload.array('files'), async (req, res) => {
  let cacheText = req.body.textInput
  const OGfileNames = req.files || '';
  let fileData = ''
  OGfileNames.forEach(file => {fileData = fileData.concat(file.originalname + '三' + file.filename + '二')})
  try {
    fs.appendFile(`./lobbies/${cacheLobby}/log.txt`, '\r\n' + cacheUsername.usernames + '一' + fileData + '一' + cacheText,'utf8', (err, data) => {
      if (err) {
      console.error('Error appending to file:', err);
      return;
    }
  })
  } catch {
    console.log('Damn')
  }
  res.redirect('/lobbies/' + cacheLobby)
})

app.post('/upload', upload.array('myFiles'), (req, res) => {
    if (!req.files || req.files.length === 0) {
        return res.status(400).json({ message: 'No files uploaded' });
    }
    res.json({ message: 'Success', count: req.files.length });
});

app.get('/register', checkNotAuthenticated, (req, res) => {
  res.render('register.ejs')
})

app.post('/register', checkNotAuthenticated, async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10)
    await db.query(`
      INSERT INTO accounts (usernames, passwords)
      VALUES ('${req.body.username}', '${hashedPassword}')
      `)
    res.redirect('/login')
  } catch {
    res.redirect('/register')
  }
})

app.get('/createLobby', checkAuthenticated, (req, res) => {
  res.render('createLobby.ejs')
})

app.post('/createLobby', checkAuthenticated, async (req, res) => {
  const lobbyCode = await makeLobbyID()
  fs.mkdir('./lobbies/' + lobbyCode, (error) => {
    if (error) {
      console.log(error)
    } else {
      fs.writeFile('./lobbies/' + lobbyCode + '/log.txt', req.body.create, 'utf8', (err) => {
        if (err) {
          console.error('Error writing file:', err);
          return;
        }
        //registerLobby(req.session.passport.user, lobbyCode)
        db.query(`INSERT INTO lobbies (id, lobby, lNames) VALUES (${req.session.passport.user}, '${lobbyCode}', '${req.body.create}')`)
      })
    }
  })
  res.redirect('/')
})

app.delete('/logout', (req, res) => {
  req.logout(function(err) { 
    if (err) { return next(err); } 
    res.redirect('/login');
    cacheLobby = null
    cacheUsername = null
  });   
});

function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next()
  }

  res.redirect('/login')
}

function checkNotAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect('/')
  }
  next()
} 

function e() {
  const idk = 'Bob;Image;idk.Kevin;Image;idk'
  const idkarray = idk.split(".")
  const idkarray2 = []
  for (i=0; i<idkarray.length; i++) {
    idkarray2.push(idkarray[i].split(';'))
  }
  console.log(idkarray2)
}

function f() {
  fs.readFile('./lobbies/lobby/lobby.txt', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return;
    }
    const string = data.split("\n")
    console.log(string[0])
  });
}

async function g() {
  [idk1] = await db.query("SELECT lobby FROM lobbies WHERE lobby = 'lobby3'")
  return idk1
}


async function g2() {
  idk2 = await g()
  console.log(idk2)
}

//e()
//console.log(makeLobbyID())
app.listen(3000)
fs.exist